package com.api.tripcallv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripcallvApplicationTests {

	@Test
	void contextLoads() {
	}

}
